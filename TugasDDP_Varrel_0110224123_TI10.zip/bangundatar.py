import modulbangundatar

# Input dan Perhitungan
print("Pilih bangun datar untuk menghitung luas:")
print("1. Lingkaran")
print("2. Persegi")
print("3. Segitiga")
print("4. Persegi Panjang")
print("5. Jajar Genjang")

pilihan = int(input("Masukkan pilihan Anda (1-5): "))

if pilihan == 1:
    jari_jari = float(input("Masukkan jari-jari lingkaran: "))
    print(f"Luas Lingkaran: {modulbangundatar.luas_lingkaran(jari_jari):.2f}")

elif pilihan == 2:
    sisi = float(input("Masukkan panjang sisi persegi: "))
    print(f"Luas Persegi: {modulbangundatar.luas_persegi(sisi)}")

elif pilihan == 3:
    alas = float(input("Masukkan panjang alas segitiga: "))
    tinggi = float(input("Masukkan tinggi segitiga: "))
    print(f"Luas Segitiga: {modulbangundatar.luas_segitiga(alas, tinggi)}")

elif pilihan == 4:
    panjang = float(input("Masukkan panjang persegi panjang: "))
    lebar = float(input("Masukkan lebar persegi panjang: "))
    print(f"Luas Persegi Panjang: {modulbangundatar.luas_persegi_panjang(panjang, lebar)}")

elif pilihan == 5:
    alas = float(input("Masukkan panjang alas jajar genjang: "))
    tinggi = float(input("Masukkan tinggi jajar genjang: "))
    print(f"Luas Jajar Genjang: {modulbangundatar.luas_jajar_genjang(alas, tinggi)}")

else:
    print("Pilihan tidak valid.")