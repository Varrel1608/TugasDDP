import math

# Fungsi untuk menghitung luas permukaan Kubus
def luas_kubus(sisi):
    """Menghitung luas permukaan kubus: 6 × s²"""
    return 6 * (sisi ** 2)

# Fungsi untuk menghitung luas permukaan Balok
def luas_balok(panjang, lebar, tinggi):
    """Menghitung luas permukaan balok: 2 × (p × l + p × t + l × t)"""
    return 2 * (panjang * lebar + panjang * tinggi + lebar * tinggi)

# Fungsi untuk menghitung luas permukaan Tabung
def luas_tabung(jari_jari, tinggi):
    """Menghitung luas permukaan tabung: 2 × π × r × (r + t)"""
    return 2 * math.pi * jari_jari * (jari_jari + tinggi)

# Fungsi untuk menghitung luas permukaan Limas Segiempat
def luas_limas_segiempat(panjang, lebar, tinggi):
    """
    Menghitung luas permukaan limas segiempat:
    Luas alas + 4 × (½ × alas × tinggi sisi miring)
    """
    luas_alas = panjang * lebar
    tinggi_sisi_miring = math.sqrt((tinggi ** 2) + (0.5 * panjang) ** 2)
    luas_sisi = 2 * panjang * tinggi_sisi_miring
    return luas_alas + luas_sisi

# Fungsi untuk menghitung luas permukaan Prisma Segitiga
def luas_prisma_segitiga(alas, tinggi_segitiga, tinggi_prisma):
    """
    Menghitung luas permukaan prisma segitiga:
    2 × luas segitiga + keliling segitiga × tinggi prisma
    """
    luas_segitiga = 0.5 * alas * tinggi_segitiga
    keliling_segitiga = 3 * alas  # Asumsi segitiga sama sisi
    luas_selimut = keliling_segitiga * tinggi_prisma
    return 2 * luas_segitiga + luas_selimut
