import aritmatika_modul

def hitungan_aritmatika():
    print("\nPilih operasi aritmatika yang ingin dilakukan:")
    print("1.Penambahan")
    print("2.Pengurangan")
    print("3.Perkalian")
    print("4.Pembagian")
    print("5.Pangkat")
    pilihan=int(input("\nMasukkan nomor aritmatika yang dipilih:"))

    if pilihan == 1:
        a = float(input("masukkan angka pertama:"))
        b = float(input("masukkan angka kedua:"))
        print("Hasil Penambahan:",aritmatika_modul.tambah(a,b))
    elif pilihan == 2:
         a = float(input("masukkan angka pertama:"))
         b = float(input("masukkan angka kedua:"))
         print("Hasil Pengurangan:",aritmatika_modul.kurang (a,b))
    elif pilihan == 3:
         a = float(input("masukkan angka pertama:"))
         b = float(input("masukkan angka kedua:"))
         print("Hasil Perkalian:", aritmatika_modul.kali (a,b))
    elif pilihan == 4:
         a = float(input("masukkan angka pertama:"))
         b = float(input("masukkan angka kedua:"))
         print("Hasil Pembagian:",aritmatika_modul.bagi (a,b))
    elif pilihan == 5:
         a = float(input("masukkan angka pertama:"))
         b = float(input("masukkan angka kedua:"))
         print("Hasil Pembagian:",aritmatika_modul.pangkat (a,b))
    
        

                      