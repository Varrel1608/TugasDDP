import modulbangunruang

# Input dan Perhitungan
print("Pilih bangun ruang untuk menghitung luas permukaan:")
print("1. Kubus")
print("2. Balok")
print("3. Tabung")
print("4. Limas Segiempat")
print("5. Prisma Segitiga")

pilihan = int(input("Masukkan pilihan Anda (1-5): "))

if pilihan == 1:
    sisi = float(input("Masukkan panjang sisi kubus: "))
    print(f"Luas Permukaan Kubus: {modulbangunruang.luas_kubus(sisi):.2f}")

elif pilihan == 2:
    panjang = float(input("Masukkan panjang balok: "))
    lebar = float(input("Masukkan lebar balok: "))
    tinggi = float(input("Masukkan tinggi balok: "))
    print(f"Luas Permukaan Balok: {modulbangunruang.luas_balok(panjang, lebar, tinggi):.2f}")

elif pilihan == 3:
    jari_jari = float(input("Masukkan jari-jari alas tabung: "))
    tinggi = float(input("Masukkan tinggi tabung: "))
    print(f"Luas Permukaan Tabung: {modulbangunruang.luas_tabung(jari_jari, tinggi):.2f}")

elif pilihan == 4:
    panjang = float(input("Masukkan panjang alas limas segiempat: "))
    lebar = float(input("Masukkan lebar alas limas segiempat: "))
    tinggi = float(input("Masukkan tinggi limas segiempat: "))
    print(f"Luas Permukaan Limas Segiempat: {modulbangunruang.luas_limas_segiempat(panjang, lebar, tinggi):.2f}")

elif pilihan == 5:
    alas = float(input("Masukkan panjang alas segitiga prisma: "))
    tinggi_segitiga = float(input("Masukkan tinggi segitiga alas prisma: "))
    tinggi_prisma = float(input("Masukkan tinggi prisma: "))
    print(f"Luas Permukaan Prisma Segitiga: {modulbangunruang.luas_prisma_segitiga(alas, tinggi_segitiga, tinggi_prisma):.2f}")

else:
    print("Pilihan tidak valid.")
