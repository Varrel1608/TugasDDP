import math

# Fungsi untuk menghitung luas Lingkaran
def luas_lingkaran(jari_jari):
    """Menghitung luas lingkaran: π × r²"""
    return math.pi * (jari_jari ** 2)

# Fungsi untuk menghitung luas Persegi
def luas_persegi(sisi):
    """Menghitung luas persegi: s²"""
    return sisi ** 2

# Fungsi untuk menghitung luas Segitiga
def luas_segitiga(alas, tinggi):
    """Menghitung luas segitiga: ½ × alas × tinggi"""
    return 0.5 * alas * tinggi

# Fungsi untuk menghitung luas Persegi Panjang
def luas_persegi_panjang(panjang, lebar):
    """Menghitung luas persegi panjang: p × l"""
    return panjang * lebar

# Fungsi untuk menghitung luas Jajar Genjang
def luas_jajar_genjang(alas, tinggi):
    """Menghitung luas jajar genjang: alas × tinggi"""
    return alas * tinggi
